<!-- SETUP -->
STEP 1 - create a workspace/src
STEP 2 - rosdep
STEP 3 - colcon build

<!-- Spawning of Models -->
![alt text](image.png)

<!-- Inter Communication of Robots using nav2 -->
in the folder